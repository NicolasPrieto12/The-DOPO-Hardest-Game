package domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para la clase {@link Coin}.
 * Verifica el comportamiento de recolección, restablecimiento
 * y detección de colisiones de la moneda.
 */
class CoinTest {

    /** Moneda usada en cada prueba, creada en la posición (100, 100). */
    private Coin coin;

    /**
     * Crea una moneda nueva antes de cada prueba para garantizar
     * que cada test parte de un estado limpio.
     */
    @BeforeEach
    void setUp() {
        coin = new Coin(100, 100);
    }

    /**
     * Verifica que una moneda recién creada no esté marcada como recogida.
     */
    @Test
    void coinIniciaNoRecogida() {
        assertFalse(coin.isCollected());
    }

    /**
     * Verifica que al llamar {@code collect()} la moneda quede marcada como recogida.
     */
    @Test
    void collectMarcaMonedaComoRecogida() {
        coin.collect();
        assertTrue(coin.isCollected());
    }

    /**
     * Verifica que {@code reset()} devuelva la moneda a su estado inicial
     * (no recogida) después de haber sido recolectada.
     */
    @Test
    void resetRestableceCoinANoRecogida() {
        coin.collect();
        coin.reset();
        assertFalse(coin.isCollected());
    }

    /**
     * Verifica que se detecte colisión cuando el jugador está en la misma posición que la moneda.
     */
    @Test
    void colisionConJugadorCercanoRetornaTrue() {
        Player player = new Player(100, 100);
        assertTrue(coin.collidesWith(player));
    }

    /**
     * Verifica que una moneda ya recogida no genere colisión,
     * aunque el jugador esté en la misma posición.
     */
    @Test
    void noHayColisionSiMonedaYaFueRecogida() {
        Player player = new Player(100, 100);
        coin.collect();
        assertFalse(coin.collidesWith(player));
    }

    /**
     * Verifica que no haya colisión cuando el jugador está lejos de la moneda.
     */
    @Test
    void noHayColisionConJugadorLejos() {
        Player player = new Player(500, 500);
        assertFalse(coin.collidesWith(player));
    }

    /**
     * Verifica que {@code getBounds()} retorne el rectángulo correcto
     * con la posición y tamaño esperados de la moneda.
     */
    @Test
    void getBoundsRetornaTamanoCorrecto() {
        assertEquals(100, coin.getBounds().x);
        assertEquals(100, coin.getBounds().y);
        assertEquals(12,  coin.getBounds().width);
        assertEquals(12,  coin.getBounds().height);
    }
}
