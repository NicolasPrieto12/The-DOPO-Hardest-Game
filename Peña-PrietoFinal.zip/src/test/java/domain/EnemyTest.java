package domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.Rectangle;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para la clase {@link Enemy}.
 * Verifica el desplazamiento lineal, el rebote en los bordes del tablero,
 * el respeto de zonas prohibidas y la detección de colisiones con el jugador.
 */
class EnemyTest {

    /** Enemigo usado en cada prueba, moviéndose hacia la derecha desde (300, 250). */
    private Enemy enemy;

    /** Ancho del tablero de prueba. */
    private static final int BW = 800;

    /** Alto del tablero de prueba. */
    private static final int BH = 500;

    /**
     * Crea un enemigo nuevo antes de cada prueba para garantizar
     * que cada test parte de un estado limpio.
     */
    @BeforeEach
    void setUp() {
        enemy = new Enemy(300, 250, 3, 0, BW, BH);
    }

    /**
     * Verifica que el enemigo avance 3 píxeles hacia la derecha en cada tick.
     */
    @Test
    void enemySeDesplazaHaciaLaDerecha() {
        enemy.move();
        assertEquals(303, enemy.getBounds().x);
    }

    /**
     * Verifica que el enemigo invierta su dirección al alcanzar el borde derecho del tablero.
     */
    @Test
    void enemyRebotaEnBordeDerecho() {
        Enemy e = new Enemy(BW - 20, 250, 3, 0, BW, BH);
        e.move();
        int xAntes = e.getBounds().x;
        e.move();
        assertTrue(e.getBounds().x < xAntes);
    }

    /**
     * Verifica que el enemigo invierta su dirección al alcanzar el borde izquierdo del tablero.
     */
    @Test
    void enemyRebotaEnBordeIzquierdo() {
        Enemy e = new Enemy(2, 250, -3, 0, BW, BH);
        e.move();
        int xAntes = e.getBounds().x;
        e.move();
        assertTrue(e.getBounds().x > xAntes);
    }

    /**
     * Verifica que el enemigo no entre en una zona prohibida,
     * invirtiendo su dirección antes de alcanzarla.
     */
    @Test
    void enemyNoEntraEnZonaProhibida() {
        Rectangle zonaProhibida = new Rectangle(290, 240, 80, 80);
        enemy.addForbiddenZone(zonaProhibida);
        int xAntes = enemy.getBounds().x;
        enemy.move();
        assertNotEquals(xAntes + 3, enemy.getBounds().x);
    }

    /**
     * Verifica que se detecte colisión cuando el jugador está en la misma posición que el enemigo.
     */
    @Test
    void colisionConJugadorEnMismaPosicion() {
        Player player = new Player(300, 250);
        assertTrue(enemy.collidesWith(player));
    }

    /**
     * Verifica que no haya colisión cuando el jugador está lejos del enemigo.
     */
    @Test
    void noHayColisionConJugadorLejos() {
        Player player = new Player(600, 400);
        assertFalse(enemy.collidesWith(player));
    }

    /**
     * Verifica que {@code getBounds()} retorne la posición correcta del enemigo.
     */
    @Test
    void getBoundsRetornaPosicionCorrecta() {
        assertEquals(300, enemy.getBounds().x);
        assertEquals(250, enemy.getBounds().y);
    }
}
