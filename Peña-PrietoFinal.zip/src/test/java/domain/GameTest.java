package domain;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para la clase {@link Game}.
 * Verifica el estado inicial, la lógica de muerte, victoria, pausa,
 * reinicio, progresión de niveles, tiempo agotado y el patrón Singleton.
 */
class GameTest {

    /** Instancia del juego bajo prueba. */
    private Game game;

    /** Jugador de prueba posicionado en la StartZone. */
    private Player player;

    /** Moneda de prueba ubicada en el centro del tablero. */
    private Coin coin;

    /** Enemigo de prueba ubicado lejos del jugador para no interferir en las pruebas. */
    private Enemy enemy;

    /** Zona de inicio del nivel de prueba. */
    private StartZone startZone;

    /** Zona final del nivel de prueba. */
    private EndZone endZone;

    /**
     * Construye una instancia limpia del juego antes de cada prueba.
     * Resetea el Singleton, crea el tablero, el jugador, la moneda,
     * el enemigo y el nivel de prueba.
     */
    @BeforeEach
    void setUp() {
        Game.resetInstance();

        startZone = new StartZone(20, 200, 80, 100);
        endZone   = new EndZone(700, 200, 80, 100);
        Board board = new Board(startZone, endZone, List.of());

        player = new Player(50, 240);
        coin   = new Coin(400, 240);
        enemy  = new Enemy(600, 400, 3, 0, 800, 500);

        Level level = new Level(1, board, List.of(enemy), List.of(coin));
        game = Game.getInstance(player, List.of(level));
    }

    /**
     * Destruye la instancia del Singleton después de cada prueba
     * para evitar interferencias entre tests.
     */
    @AfterEach
    void tearDown() {
        Game.resetInstance();
    }

    /**
     * Verifica que el estado inicial del juego sea {@link GameState#PLAYING}.
     */
    @Test
    void estadoInicialEsPlaying() {
        assertEquals(GameState.PLAYING, game.getState());
    }

    /**
     * Verifica que el contador de muertes inicie en cero.
     */
    @Test
    void muertesInicialesEnCero() {
        assertEquals(0, game.getDeaths());
    }

    /**
     * Verifica que el tiempo inicial sea de 180 segundos (3 minutos).
     */
    @Test
    void tiempoInicialEsTresMinutos() {
        assertEquals(180, game.getSecondsLeft());
    }

    /**
     * Verifica que {@code checkDeath()} incremente el contador de muertes en 1.
     */
    @Test
    void checkDeathIncrementaMuertes() {
        game.checkDeath();
        assertEquals(1, game.getDeaths());
    }

    /**
     * Verifica que {@code checkDeath()} restablezca las monedas recogidas
     * a su estado original.
     */
    @Test
    void checkDeathRestableceLasMonedas() {
        coin.collect();
        game.checkDeath();
        assertFalse(coin.isCollected());
    }

    /**
     * Verifica que {@code checkDeath()} reposicione al jugador
     * dentro del área de la StartZone.
     */
    @Test
    void checkDeathReposicionaJugador() {
        player.setPosition(600, 300);
        game.checkDeath();
        assertTrue(player.getX() >= 20 && player.getX() <= 100);
    }

    /**
     * Verifica que {@code checkWin()} retorne false cuando no se han recogido monedas.
     */
    @Test
    void checkWinRetornaFalseSinMonedas() {
        assertFalse(game.checkWin());
    }

    /**
     * Verifica que {@code checkWin()} retorne false cuando las monedas están recogidas
     * pero el jugador no está en la EndZone.
     */
    @Test
    void checkWinRetornaFalseConMonedasPeroFueraDeEndZone() {
        coin.collect();
        assertFalse(game.checkWin());
    }

    /**
     * Verifica que {@code checkWin()} retorne true cuando todas las monedas
     * están recogidas y el jugador está dentro de la EndZone.
     */
    @Test
    void checkWinRetornaTrueConMonedasYEnEndZone() {
        coin.collect();
        player.setPosition(720, 240);
        assertTrue(game.checkWin());
    }

    /**
     * Verifica que {@code pause()} alterne correctamente entre
     * {@link GameState#PLAYING} y {@link GameState#PAUSED}.
     */
    @Test
    void pauseAlternaEntrePlayingYPaused() {
        game.pause();
        assertEquals(GameState.PAUSED, game.getState());
        game.pause();
        assertEquals(GameState.PLAYING, game.getState());
    }

    /**
     * Verifica que {@code restart()} reinicie el contador de muertes
     * y el tiempo a sus valores iniciales.
     */
    @Test
    void restartReiniciaDeathsYTiempo() {
        game.checkDeath();
        game.checkDeath();
        game.restart();
        assertEquals(0, game.getDeaths());
        assertEquals(180, game.getSecondsLeft());
    }

    /**
     * Verifica que {@code restart()} cambie el estado del juego a {@link GameState#PLAYING}
     * independientemente del estado anterior.
     */
    @Test
    void restartCambiaEstadoAPlaying() {
        game.pause();
        game.restart();
        assertEquals(GameState.PLAYING, game.getState());
    }

    /**
     * Verifica que {@code nextLevel()} cambie el estado a {@link GameState#WIN}
     * cuando no hay más niveles disponibles.
     */
    @Test
    void nextLevelCambiaEstadoAWinSiNoHayMasNiveles() {
        game.nextLevel();
        assertEquals(GameState.WIN, game.getState());
    }

    /**
     * Verifica que el estado cambie a {@link GameState#TIMEOUT}
     * cuando el tiempo del nivel se agota completamente (180 segundos × 60 ticks).
     */
    @Test
    void tiempoAgotadoCambiaEstadoATimeout() {
        for (int i = 0; i < 180 * 60; i++) {
            game.update();
        }
        assertEquals(GameState.TIMEOUT, game.getState());
    }

    /**
     * Verifica que el patrón Singleton retorne siempre la misma instancia de {@link Game}.
     */
    @Test
    void getInstanceRetornaMismaInstancia() {
        Game mismaInstancia = Game.getInstance();
        assertSame(game, mismaInstancia);
    }
}
