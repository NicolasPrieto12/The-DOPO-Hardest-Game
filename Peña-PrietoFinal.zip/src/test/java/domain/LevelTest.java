package domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para la clase {@link Level}.
 * Verifica la lógica de completado del nivel, el restablecimiento
 * de monedas y jugador, y los métodos de acceso a sus elementos.
 */
class LevelTest {

    /** Nivel usado en cada prueba. */
    private Level level;

    /** Jugador de prueba posicionado dentro de la StartZone. */
    private Player player;

    /** Moneda de prueba ubicada en el centro del tablero. */
    private Coin coin;

    /** Enemigo de prueba que se mueve horizontalmente. */
    private Enemy enemy;

    /**
     * Construye un nivel completo con tablero, jugador, moneda y enemigo
     * antes de cada prueba para garantizar un estado limpio.
     */
    @BeforeEach
    void setUp() {
        StartZone start = new StartZone(20, 200, 80, 100);
        EndZone   end   = new EndZone(700, 200, 80, 100);
        Board board = new Board(start, end, List.of());

        player = new Player(50, 240);
        coin   = new Coin(400, 240);
        enemy  = new Enemy(300, 240, 3, 0, 800, 500);

        level = new Level(1, board, List.of(enemy), List.of(coin));
    }

    /**
     * Verifica que el nivel no esté completado cuando la moneda no ha sido recogida.
     */
    @Test
    void nivelNoEstaCompletadoSinRecogerMonedas() {
        assertFalse(level.isCompleted());
    }

    /**
     * Verifica que el nivel se marque como completado cuando todas las monedas
     * han sido recogidas.
     */
    @Test
    void nivelCompletadoCuandoTodasLasMonedasRecogidas() {
        coin.collect();
        assertTrue(level.isCompleted());
    }

    /**
     * Verifica que {@code reset()} restablezca todas las monedas
     * a su estado no recogido.
     */
    @Test
    void resetRestableceMonedasYPosicionJugador() {
        coin.collect();
        level.reset(player);
        assertFalse(coin.isCollected());
    }

    /**
     * Verifica que {@code reset()} reposicione al jugador dentro
     * del área de la StartZone.
     */
    @Test
    void resetReposicionaJugadorEnStartZone() {
        player.setPosition(600, 300);
        level.reset(player);
        assertTrue(player.getX() >= 20 && player.getX() <= 100);
        assertTrue(player.getY() >= 200 && player.getY() <= 300);
    }

    /**
     * Verifica que {@code getLevelNumber()} retorne el número correcto del nivel.
     */
    @Test
    void getLevelNumberRetornaNumeroCorreecto() {
        assertEquals(1, level.getLevelNumber());
    }

    /**
     * Verifica que {@code getEnemies()} retorne la lista con el número correcto de enemigos.
     */
    @Test
    void getEnemiesRetornaListaCorrecta() {
        assertEquals(1, level.getEnemies().size());
    }

    /**
     * Verifica que {@code getCoins()} retorne la lista con el número correcto de monedas.
     */
    @Test
    void getCoinsRetornaListaCorrecta() {
        assertEquals(1, level.getCoins().size());
    }
}
