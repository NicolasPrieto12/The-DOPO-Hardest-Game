package domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para la clase {@link Player}.
 * Verifica el estado inicial, el movimiento en las cuatro direcciones,
 * la colisión con paredes, el respawn y la detección de colisiones.
 */
class PlayerTest {

    /** Jugador usado en cada prueba, creado en la posición (100, 100). */
    private Player player;

    /**
     * Crea un jugador nuevo antes de cada prueba para garantizar
     * que cada test parte de un estado limpio.
     */
    @BeforeEach
    void setUp() {
        player = new Player(100, 100);
    }

    /**
     * Verifica que el jugador inicie en estado vivo al ser creado.
     */
    @Test
    void playerIniciaVivo() {
        assertTrue(player.isAlive());
    }

    /**
     * Verifica que el jugador inicie en las coordenadas indicadas en el constructor.
     */
    @Test
    void playerIniciaEnPosicionCorrecta() {
        assertEquals(100, player.getX());
        assertEquals(100, player.getY());
    }

    /**
     * Verifica que {@code setPosition()} actualice correctamente las coordenadas del jugador.
     */
    @Test
    void setPositionActualizaCoordenadas() {
        player.setPosition(200, 300);
        assertEquals(200, player.getX());
        assertEquals(300, player.getY());
    }

    /**
     * Verifica que {@code respawn()} devuelva al jugador a su posición inicial
     * y lo marque como vivo.
     */
    @Test
    void respawnVuelveAPosicionInicial() {
        player.setPosition(400, 400);
        player.respawn();
        assertEquals(100, player.getX());
        assertEquals(100, player.getY());
        assertTrue(player.isAlive());
    }

    /**
     * Verifica que se detecte colisión cuando dos jugadores están en la misma posición.
     */
    @Test
    void colisionConOtroJugadorEnMismaPosicion() {
        Player otro = new Player(100, 100);
        assertTrue(player.collidesWith(otro));
    }

    /**
     * Verifica que no haya colisión cuando el otro jugador está lejos.
     */
    @Test
    void noHayColisionConJugadorLejos() {
        Player otro = new Player(500, 500);
        assertFalse(player.collidesWith(otro));
    }

    /**
     * Verifica que {@code getBounds()} retorne el rectángulo correcto
     * con la posición y tamaño esperados del jugador.
     */
    @Test
    void getBoundsRetornaTamanoCorrecto() {
        assertEquals(100, player.getBounds().x);
        assertEquals(100, player.getBounds().y);
        assertEquals(20,  player.getBounds().width);
        assertEquals(20,  player.getBounds().height);
    }

    /**
     * Verifica que activar el movimiento hacia arriba reduzca la coordenada Y del jugador.
     */
    @Test
    void movimientoHaciaArribaReduceY() {
        player.setMovingUp(true);
        player.move();
        assertTrue(player.getY() < 100);
    }

    /**
     * Verifica que activar el movimiento hacia abajo aumente la coordenada Y del jugador.
     */
    @Test
    void movimientoHaciaAbajoAumentaY() {
        player.setMovingDown(true);
        player.move();
        assertTrue(player.getY() > 100);
    }

    /**
     * Verifica que activar el movimiento hacia la izquierda reduzca la coordenada X del jugador.
     */
    @Test
    void movimientoHaciaIzquierdaReduceX() {
        player.setMovingLeft(true);
        player.move();
        assertTrue(player.getX() < 100);
    }

    /**
     * Verifica que activar el movimiento hacia la derecha aumente la coordenada X del jugador.
     */
    @Test
    void movimientoHaciaDerechaAumentaX() {
        player.setMovingRight(true);
        player.move();
        assertTrue(player.getX() > 100);
    }

    /**
     * Verifica que el jugador no se mueva si no hay ninguna tecla de dirección activa.
     */
    @Test
    void sinTeclasPresadasNoSemueve() {
        player.move();
        assertEquals(100, player.getX());
        assertEquals(100, player.getY());
    }

    /**
     * Verifica que una pared bloquee el movimiento del jugador hacia arriba,
     * manteniendo su posición Y sin cambios.
     */
    @Test
    void paredBloqueaMovimientoHaciaArriba() {
        java.util.List<java.awt.Rectangle> walls = java.util.List.of(
            new java.awt.Rectangle(0, 90, 800, 20)
        );
        player.setWalls(walls);
        player.setMovingUp(true);
        player.move();
        assertEquals(100, player.getY());
    }
}
